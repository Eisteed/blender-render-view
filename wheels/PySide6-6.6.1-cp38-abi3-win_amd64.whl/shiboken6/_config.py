shiboken_library_soversion = str(6.6)

version = "6.6.1"
version_info = (6, 6, 1, "", "")

__build_date__ = '2023-11-27T13:30:55+00:00'




__setup_py_package_version__ = '6.6.1'

