shiboken_library_soversion = "6.9"

version = "6.9.3"
version_info = (6, 9, 3, "", "")

__build_date__ = '2025-09-29T14:41:04+00:00'




__setup_py_package_version__ = '6.9.3'

